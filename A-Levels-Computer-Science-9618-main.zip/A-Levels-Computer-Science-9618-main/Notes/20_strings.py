cies = input("Please input a string: ")

'''
A string is AN ARRAY OF characters
    The first character in a string would have position 0
    And the last character would have position length-1
'''

first = cies[0]

'Print the first 4 characters of the string (i.e 0 1 2 3)'
# SLICE THE STRING
slice1 = cies[0:4]

'find out the length of the string'
stringLength = len(cies)
