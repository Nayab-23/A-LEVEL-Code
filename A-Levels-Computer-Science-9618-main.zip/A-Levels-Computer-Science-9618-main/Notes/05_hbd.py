'''
Prompt the user to input a number and then you have to tell him
Happy Birthday that many times

PROGRAMMERS = LAZY, KAAM CHOR, AALSI
LOOPS

WHICH LOOP?
    since count is known, use a FOR LOOP
'''

# DECLARE count : INT
count = int(input("Please enter a number: "))
for i in range(count):
    print("Happy Birthday")