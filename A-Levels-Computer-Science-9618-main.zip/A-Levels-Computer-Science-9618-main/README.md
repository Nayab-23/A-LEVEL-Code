# A Levels Computer Science (9618)

<p>
  <a href="https://www.instagram.com/kurlyatzainematics/" target="_blank">
    <img src="https://cdn-icons-png.flaticon.com/512/174/174855.png" alt="Instagram" width="30" height="30">
  </a>
  &nbsp; DM for queries, suggestions, and recommendations.
</p>

---

## 📘 Notes

👉 [Visit our website for complete syllabus notes](https://www.zainematics.com/computer-science-notes)

---

## 🎥 Syllabus Videos

<!-- Playlist 1 -->
<p>
  <a href="https://www.youtube.com/playlist?list=PLLyqGZba3Xv2D-u3P3-p7fk9zXaRlxG5x" target="_blank">
    <img src="https://cdn-icons-png.flaticon.com/512/1384/1384060.png" alt="YouTube Playlist 1" width="30" height="30">
  </a>
  &nbsp; <strong>Paper 1</strong>
</p>

<!-- Playlist 2 -->
<p>
  <a href="https://www.youtube.com/playlist?list=PLLyqGZba3Xv1Oac_sXK5bGJjplo-mw4mP" target="_blank">
    <img src="https://cdn-icons-png.flaticon.com/512/1384/1384060.png" alt="YouTube Playlist 2" width="30" height="30">
  </a>
  &nbsp; <strong>Paper 2</strong>
</p>

<!-- Playlist 3 -->
<p>
  <a href="https://www.youtube.com/playlist?list=PLLyqGZba3Xv0pVjwNnc21_lBBCxfQoQHE" target="_blank">
    <img src="https://cdn-icons-png.flaticon.com/512/1384/1384060.png" alt="YouTube Playlist 3" width="30" height="30">
  </a>
  &nbsp; <strong>Paper 2 – Practice</strong>
</p>

<!-- Playlist 4 -->
<p>
  <a href="https://www.youtube.com/playlist?list=PLLyqGZba3Xv1VU_rzic0xB7VUXdLfXRbj" target="_blank">
    <img src="https://cdn-icons-png.flaticon.com/512/1384/1384060.png" alt="YouTube Playlist 4" width="30" height="30">
  </a>
  &nbsp; <strong>Paper 3</strong>
</p>

<!-- Playlist 5 -->
<p>
  <a href="https://www.youtube.com/playlist?list=PLLyqGZba3Xv1b1DuU85La2i_N-7lEpUt9" target="_blank">
    <img src="https://cdn-icons-png.flaticon.com/512/1384/1384060.png" alt="YouTube Playlist 5" width="30" height="30">
  </a>
  &nbsp; <strong>Paper 4</strong>
</p>
